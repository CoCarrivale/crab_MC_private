from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'VBS_semilep_ZZ_EWK_2024_v15'
config.General.workArea = 'VBS_semilep_ZZ_EWK_2024_v15'
config.section_('JobType')
config.JobType.inputFiles = ['CMSSW_15_0_2.tar.gz', 'modifyCfg.py', 'copy_gridpack.py', 'get_disk_files.py', 'runners/2024_nAODv15/run_chain_Run3.sh', 'runners/2024_nAODv15/chain_step_0_LHEGS.sh', 'runners/2024_nAODv15/chain_step_1_DRPreMix.sh', 'runners/2024_nAODv15/chain_step_4_MiniAOD.sh', 'runners/2024_nAODv15/chain_step_5_NanoAOD.sh', 'Run3/Summer24_nAODv15/cfg_RunIII2024Summer24DRPremix_0.py', 'Run3/Summer24_nAODv15/cfg_RunIII2024Summer24DRPremix.py', 'Run3/Summer24_nAODv15/cfg_RunIII2024Summer24MiniAODv6.py', 'Run3/Summer24_nAODv15/cfg_RunIII2024Summer24NanoAODv15.py', 'Run3/Summer24_nAODv15/cfg_RunIII2024Summer24wmLHEGS.py']
config.JobType.scriptExe = 'runners/2024_nAODv15/run_chain_Run3.sh'
config.JobType.psetName = 'do_nothing_cfg.py'
config.JobType.scriptArgs = ['inputGridpack=/eos/user/f/ffiore/VBS/Gridpacks/ZZ/VBS_ZZ_semilep_el8_amd64_gcc10_CMSSW_12_4_8_tarball.tar.xz', 'nEvents=20', 'nThreads=4']
config.JobType.disableAutomaticOutputCollection = False
config.JobType.outputFiles = ['RunIII2024Summer24NanoAODv15.root']
config.JobType.numCores = 4
config.JobType.allowUndistributedCMSSW = True
config.JobType.eventsPerLumi = 20
config.JobType.maxMemoryMB = 8000
config.JobType.pluginName = 'PrivateMC'
config.section_('Data')
config.Data.outputPrimaryDataset = 'VBS_semilep_ZZ_EWK_2024_v15'
config.Data.unitsPerJob = 20
config.Data.outLFNDirBase = '/store/user/ffiore/'
config.Data.outputDatasetTag = 'VBS_semilep_ZZ_EWK_2024_v15'
config.Data.publication = False
config.Data.splitting = 'EventBased'
config.Data.totalUnits = 40
config.section_('User')
config.section_('Site')
config.Site.storageSite = 'T2_IT_Legnaro'
