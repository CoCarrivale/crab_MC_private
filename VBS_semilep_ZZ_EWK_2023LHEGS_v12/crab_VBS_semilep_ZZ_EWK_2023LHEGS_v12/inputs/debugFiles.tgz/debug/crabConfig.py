from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'VBS_semilep_ZZ_EWK_2023LHEGS_v12'
config.General.requestName = 'VBS_semilep_ZZ_EWK_2023LHEGS_v12'
config.section_('JobType')
config.JobType.inputFiles = ['CMSSW_13_0_14.tar.gz', 'modifyCfg.py', 'copy_gridpack.py', 'get_disk_files.py', 'runners/2023LHEGS_SMP/run_chain_Run3.sh', 'runners/2023LHEGS_SMP/chain_step_0_LHEGS.sh', 'runners/2023LHEGS_SMP/chain_step_1_DRPreMix.sh', 'runners/2023LHEGS_SMP/chain_step_4_MiniAOD.sh', 'runners/2023LHEGS_SMP/chain_step_5_NanoAOD.sh', 'Run3/Summer23/cfg_Run3Summer23DRPremix.py', 'Run3/Summer23/cfg_Run3Summer23digiRAW.py', 'Run3/Summer23/cfg_Run3Summer23MiniAODv4.py', 'Run3/Summer23/cfg_Run3Summer23NanoAODv12.py', 'Run3/Summer23/cfg_Run3Summer23wmLHEGS.py']
config.JobType.eventsPerLumi = 20
config.JobType.numCores = 4
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = 'do_nothing_cfg.py'
config.JobType.scriptExe = 'runners/2023LHEGS_SMP/run_chain_Run3.sh'
config.JobType.disableAutomaticOutputCollection = False
config.JobType.maxMemoryMB = 8000
config.JobType.pluginName = 'PrivateMC'
config.JobType.outputFiles = ['Run3Summer23NanoAODv12.root']
config.JobType.scriptArgs = ['inputGridpack=/eos/user/f/ffiore/VBS/Gridpacks/ZZ/VBS_ZZ_semilep_el8_amd64_gcc10_CMSSW_12_4_8_tarball.tar.xz', 'nEvents=20', 'nThreads=4']
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/ffiore/'
config.Data.outputDatasetTag = 'VBS_semilep_ZZ_EWK_2023LHEGS_v12'
config.Data.outputPrimaryDataset = 'VBS_semilep_ZZ_EWK_2023LHEGS_v12'
config.Data.publication = False
config.Data.totalUnits = 40
config.Data.splitting = 'EventBased'
config.Data.unitsPerJob = 20
config.section_('User')
config.section_('Site')
config.Site.storageSite = 'T2_IT_Legnaro'
